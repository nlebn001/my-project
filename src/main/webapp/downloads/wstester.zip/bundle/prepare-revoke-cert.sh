#!/bin/sh

java -cp wstester.jar kz.gamma.certex.cms.web.services.PrepareCertRevokeXml \
    -profile profile://eToken \
    -pass 123456 \
    -alias 6485581A1BDFA0122C7C56BDF4A2D0938B4EC95EC12425F6E695E6E8DA3C7B38 \
    -output ./requests/revokeCert.xml