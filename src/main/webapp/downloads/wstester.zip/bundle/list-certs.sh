#!/bin/sh

java -cp wstester.jar kz.gamma.certex.cms.web.services.FindCertUtil \
    -profile profile://eToken \
    -pass 123456


